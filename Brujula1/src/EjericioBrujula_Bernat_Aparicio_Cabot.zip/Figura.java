

public abstract class Figura {
	
	public String nombre;
	public boolean paralelogramo;
	
	public void pintar() {
		System.out.println(nombre);;
		
	}
	
	public boolean xParalelogramo() {
		return paralelogramo;
	}

}
